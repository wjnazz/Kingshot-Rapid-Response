// src/App.jsx
import React, { useState, useEffect } from 'react';
import './App.css';
import { heroes, troopRatios } from './data/heroes';
import { calculateCounter } from './utils/calculator';
import Results from './components/Results';

function App() {
  const [scenario, setScenario] = useState('Garrison');
  const [leadHeroes, setLeadHeroes] = useState([]);
  const [joiningHeroes, setJoiningHeroes] = useState([]);
  const [ratioId, setRatioId] = useState('');
  const [counterResult, setCounterResult] = useState(null);

  // Filter heroes for dropdowns
  const availableLeads = heroes.filter(h => h.type === 'lead');
  const availableJoining = heroes.filter(h => h.type === 'joining');

  // Handle multi-select for Leads (max 3)
  const handleLeadChange = (e) => {
    const selectedOptions = Array.from(e.target.selectedOptions).map(option => option.value);
    if (selectedOptions.length <= 3) {
      setLeadHeroes(selectedOptions);
    }
  };

  // Handle multi-select for Joining (max 4)
  const handleJoiningChange = (e) => {
    const selectedOptions = Array.from(e.target.selectedOptions).map(option => option.value);
    if (selectedOptions.length <= 4) {
      setJoiningHeroes(selectedOptions);
    }
  };

  // Trigger calculation when inputs change
  useEffect(() => {
    if (scenario && leadHeroes.length > 0 && joiningHeroes.length > 0 && ratioId) {
      const selectedRatio = troopRatios.find(r => r.id === ratioId);
      const inputBuild = {
        scenario,
        leadHeroes,
        joiningHeroes,
        troopRatio: selectedRatio
      };
      
      const result = calculateCounter(inputBuild);
      setCounterResult(result);
    } else {
      setCounterResult(null); // Clear results if form is incomplete
    }
  }, [scenario, leadHeroes, joiningHeroes, ratioId]);


  return (
    <div className="app-container">
      <header>
        <h1>Kingshot Rapid Response</h1>
        <p>Tactical Counter Calculator</p>
      </header>

      <main className="main-content">
        <div className="form-container">
          <h2>Enemy Build</h2>
          
          <div className="form-group">
            <label>Scenario:</label>
            <select value={scenario} onChange={e => setScenario(e.target.value)}>
              <option value="Garrison">Garrison Defense</option>
              <option value="Attacking">Attacking</option>
            </select>
          </div>

          <div className="form-group">
            <label>Lead Heroes (Select up to 3):</label>
            <select multiple value={leadHeroes} onChange={handleLeadChange} size={4}>
              {availableLeads.map(hero => (
                <option key={hero.id} value={hero.id}>{hero.name}</option>
              ))}
            </select>
            <small>Hold Ctrl/Cmd to select multiple. Selected: {leadHeroes.length}/3</small>
          </div>

          <div className="form-group">
            <label>Joining Heroes (Select up to 4):</label>
            <select multiple value={joiningHeroes} onChange={handleJoiningChange} size={5}>
              {availableJoining.map(hero => (
                <option key={hero.id} value={hero.id}>{hero.name}</option>
              ))}
            </select>
            <small>Hold Ctrl/Cmd to select multiple. Selected: {joiningHeroes.length}/4</small>
          </div>

          <div className="form-group">
            <label>Troop Ratio (Inf/Cav/Arch):</label>
            <select value={ratioId} onChange={e => setRatioId(e.target.value)}>
              <option value="">-- Select Ratio --</option>
              {troopRatios.map(ratio => (
                <option key={ratio.id} value={ratio.id}>{ratio.label}</option>
              ))}
            </select>
          </div>
        </div>

        <div className="results-panel">
          <Results result={counterResult} />
        </div>
      </main>
    </div>
  );
}

export default App;
